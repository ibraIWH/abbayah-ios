import SwiftUI

struct CreatedOrder: Decodable {
    let orderNumber: String
    let total: Double
}

class OrderService: ObservableObject {
    static let shared = OrderService()

    private let baseURL = "https://abbayah-backend.onrender.com/api/orders"

    func placeOrder(items: [CartItem], name: String, line1: String, city: String, phone: String) async throws -> CreatedOrder {
        guard let url = URL(string: baseURL) else { throw URLError(.badURL) }
        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        if let token = AuthService.shared.token {
            req.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        }

        let itemsPayload = items.map { item in
            return [
                "productId": item.product.id,
                "quantity": item.quantity,
                "size": item.selectedSize
            ] as [String: Any]
        }

        let body: [String: Any] = [
            "items": itemsPayload,
            "shippingAddress": [
                "name": name,
                "line1": line1,
                "city": city,
                "phone": phone
            ],
            "paymentMethod": "cod"
        ]
        req.httpBody = try JSONSerialization.data(withJSONObject: body)

        let (data, response) = try await URLSession.shared.data(for: req)
        guard let http = response as? HTTPURLResponse, http.statusCode == 201 else {
            throw URLError(.badServerResponse)
        }
        return try JSONDecoder().decode(CreatedOrder.self, from: data)
    }
}
